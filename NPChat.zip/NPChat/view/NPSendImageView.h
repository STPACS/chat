//
//  NPSendImageView.h
//  Chat
//
//  Created by mac on 2020/4/10.
//  Copyright © 2020 mac. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "NPChat.h"

NS_ASSUME_NONNULL_BEGIN

@interface NPSendImageView : UIView
@property (nonatomic, assign) NPMessageSendState messageSendState;

@end

NS_ASSUME_NONNULL_END
