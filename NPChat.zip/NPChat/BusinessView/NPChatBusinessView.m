

//
//  NPChatBusinessView.m
//  NutritionPlan
//
//  Created by mac on 2020/4/17.
//  Copyright © 2020 laj. All rights reserved.
//

#import "NPChatBusinessView.h"

@interface NPChatBusinessView()

@property (nonatomic, strong) UIView *backView;

@property (nonatomic, strong) UILabel *titleLabels;

//@property (nonatomic, strong) UILabel *detailLabel;

@property (nonatomic, strong) UIButton *checkDetailBtn;

@end

@implementation NPChatBusinessView

- (instancetype)initWithFrame:(CGRect)frame {
    if (self = [super initWithFrame:frame]) {
        
        self.frame = CGRectMake(0, 0, ScreenWidth(), real(75));
        self.backgroundColor = [UIColor colorWithHexString:@"#F6F7FB"];
        
        [self addSubview:self.backView];
        [self.backView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.edges.mas_equalTo(UIEdgeInsetsMake(real(5), real(15), real(5), real(15)));
        }];
        self.backView.backgroundColor = [UIColor colorWithHexString:@"FFFFFF"];
        self.backView.userInteractionEnabled = NO;
        
        [self.backView addSubview:self.titleLabels];
        [self.titleLabels mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.mas_equalTo(self.backView.mas_left).mas_offset(real(15));
            make.centerY.mas_equalTo(self.backView.mas_centerY);
            make.height.mas_equalTo(real(17));
        }];
        
//        [self.backView addSubview:self.detailLabel];
//        [self.detailLabel mas_makeConstraints:^(MASConstraintMaker *make) {
//            make.left.mas_equalTo(self.backView.mas_left).mas_offset(real(15));
//            make.top.mas_equalTo(self.titleLabels.mas_bottom).mas_offset(real(5));
//            make.height.mas_equalTo(real(17));
//        }];
        
        [self.backView addSubview:self.checkDetailBtn];
        [self.checkDetailBtn mas_makeConstraints:^(MASConstraintMaker *make) {
            make.right.mas_equalTo(self.backView.mas_right).mas_offset(real(-15));
            make.centerY.mas_equalTo(self.backView.mas_centerY);
            make.height.mas_equalTo(real(17));
        }];
        
        [self.checkDetailBtn setTitle:@"查看详情" forState:UIControlStateNormal];
        [self.checkDetailBtn setTitleColor:[UIColor colorWithHexString:@"#3874F5"] forState:UIControlStateNormal];
        self.checkDetailBtn.titleLabel.font = [UIFont systemFontOfSize:real(14)];
        [self.checkDetailBtn setImage:[UIImage imageNamed:@"areaMore"] forState:UIControlStateNormal];
        [self.checkDetailBtn sz_layoutImageRightWithMargin:real(2)];

    }
    return self;
}

- (void)setDisplayMessage:(NSDictionary *)displayMessage {
    _displayMessage = displayMessage;
    self.titleLabels.text = [displayMessage objectForKey:@"title"];
//    self.detailLabel.text = [displayMessage objectForKey:@"detail"];

}

- (UIView *)backView {
    if (_backView == nil) {
        _backView = [[UIView alloc]init];
        
    }
    return _backView;
}

- (UILabel *)titleLabels {
    if (_titleLabels == nil) {
        _titleLabels = [[UILabel alloc]init];
        _titleLabels.font = [UIFont boldSystemFontOfSize:real(16)];
        _titleLabels.textColor = [UIColor colorWithHexString:@"#1B2126"];
    }
    return _titleLabels;
}
//
//- (UILabel *)detailLabel {
//    if (_detailLabel == nil) {
//        _detailLabel = [[UILabel alloc]init];
//        _detailLabel.font = [UIFont boldSystemFontOfSize:real(12)];
//        _detailLabel.textColor = [UIColor colorWithHexString:@"#949494"];
//    }
//    return _detailLabel;
//}

- (UIButton *)checkDetailBtn {
    if (_checkDetailBtn == nil) {
        _checkDetailBtn = [UIButton buttonWithType:UIButtonTypeCustom];
    }
    return _checkDetailBtn;
}

@end
