//
//  NPChatBusinessView.h
//  NutritionPlan
//
//  Created by mac on 2020/4/17.
//  Copyright © 2020 laj. All rights reserved.
//

#import <UIKit/UIKit.h>

NS_ASSUME_NONNULL_BEGIN

@interface NPChatBusinessView : UIButton

@property (nonatomic, strong) NSDictionary *displayMessage;




@end

NS_ASSUME_NONNULL_END
